

let component = sandbox.CreateComponent("Component");

let text = component.createOption("A text", "text", "Hello world");

let numb = component.createOption("A number", "number", 1000);

async function start() {

  console.log("Start:", text.value, numb.value)
};

async function update() {

  await sandbox.Timeout(1000)

  console.log("Update:", text.value, numb.value)
};

