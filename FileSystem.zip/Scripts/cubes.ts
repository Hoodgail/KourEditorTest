
let material: Material;
let group: Group;

async function start() {

  group = await lib.AddGroup("Circle cubes");

  [material] = await lib.GetMaterials("CubeMat");

  if (material == undefined) {

    material = await lib.CreateMaterial("Lambert");

    await lib.SetMaterialValue(material, "name", "CubeMat");

  };

  const radius = 5;
  const cubes: Object3D[] = [];

  for (let i = 0; i < 20; i++) {

    const cube = await lib.AddDefaultObject('cube', {
      width: 1,
      height: 1,
      depth: 1,
      widthSegments: 1,
      heightSegments: 1,
      depthSegments: 1,
      material: material
    }, group);

    let x = radius * Math.cos(i / 20 * 2 * Math.PI);
    let y = radius * Math.sin(i / 20 * 2 * Math.PI);

    await lib.SetPosition(cube, false, [x, y, 0]);

    cubes.push(cube);
  }
};

async function update() {

  await sandbox.Timeout(1000);

  let scale = Math.abs(Math.sin(Date.now() / 400) * 0.75);

  await lib.SetScale(group, false, [scale, scale, scale])
}
